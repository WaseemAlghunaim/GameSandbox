﻿using System;
using System.Collections.Generic;
using System.Text;

namespace COMP4081Project{
	public class Card
	{

		public int Value;
		public string Suit = String.Empty;
		public Card(int value, string suit)
		{
			Value = value;
			Suit = suit;
		}
	}
}
