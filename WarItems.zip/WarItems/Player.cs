﻿using System;
using System.Collections.Generic;
using System.Security;
using System.Text;

namespace COMP4081Project
{
    public class Player // This class will hold each individual player
    {
        private string name; // Holds the client's username   
        private int score; // Holds the client's current game score
        // private ScoreBoard scoreBoard;  // This will hold the client's previous scores, including what game was played
        public List<Card> hand = new List<Card>(); // This holds the player's current hand in the game


  

        public Player(string name)
        {
            this.name = name;
            this.score = 0;
        }

        public bool addCard(Card card)
        {
          foreach(Card aCard in hand) // Just in case, this foreach loop iterates through the player's current hand to make sure the card is not already there
            {
                if (card.Value == aCard.Value && card.Suit.Equals(aCard.Suit)){
                    return false; // If it's in there, return false
                }
            }

            hand.Add(card); // If it's gotten to this point in the method, the card is not in there, so add the card and return true
            return true;
        }

        public Card removeCard(Card card)
        {
            foreach (Card aCard in hand) // Just in case, this foreach loop iterates through the player's current hand to make sure the card is there
            {
                if (card.Value == aCard.Value && card.Suit.Equals(aCard.Suit))
                {
                    hand.Remove(aCard);
                    return aCard; // If it's in there, return the card
                }
            }


            return null; // If the card is not there, return null
        }

        public Card removeTopCard()
        {

            return removeCard(hand[0]);
        }


        public string getName() { return name; } // A getter for the name

        public int getScore() { return score; } // A getter for the score

        public void setScore(int score) { this.score = score; } // A setter for the score

        public void clearScore(int baseScore)  { this.score = baseScore; } // A function that clears the score for the player

        public void clearDeck(){ this.hand = new List<Card>(); } // A function that clears the deck by creating a new empty hand

    }
}