﻿using System;
using System.Collections.Generic;

namespace COMP4081Project
{
    public class Game
    {
        private ScoreBoard sb;
        private CreateDeck deck;
        private List<Player> players;
        private string joinCode;

        public Game(Player player, int[] rules, string joinCode)
        {
            addPlayer(player);
            deck = new CreateDeck(rules);
            this.joinCode = joinCode;
        }

        public void addPlayer(Player player)
        {
            players.Add(player);
            sb.addPlayer(player);
        }

        public void updateScores()
        {
            sb.updateScores(players);
        }
    }
}
