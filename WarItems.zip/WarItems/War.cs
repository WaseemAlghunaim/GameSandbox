﻿using System;
using System.Collections.Generic;

namespace COMP4081Project
{
    public class War
    {
        private ScoreBoard sb;
        private List<Card> deck;
        private List<Player> players;
        private string joinCode;
        readonly int MAXIMUM_PLAYERS = 2;
        private bool gameWon = false;
        private readonly int[] rules = { 1, 1, 1, 1, 0 };

        public War()
        {
           
            deck = new CreateDeck(rules).deck;

        }

        public void addPlayer(Player player)
        {
            if (players.Count <= MAXIMUM_PLAYERS) // Makes sure the maximum number of players is not exceeded
            {
                players.Add(player);
                sb.addPlayer(player);
                player.setScore(26);
            }

            else
            {
                Console.WriteLine("Sorry, only " + MAXIMUM_PLAYERS + " players allowed in this game.");
            }

            if (players.Count == MAXIMUM_PLAYERS)
            { 
                for (int i = 0; i < deck.Capacity; i+=2)
                {

                    foreach (Player p in players)
                    {
                        p.addCard(deck[i]);
                    }

                    
                }
            }
            
        }

        public void updateScores()
        {
            sb.updateScores(players);
        }

        public void playGame()
        {
            while(!gameWon)
            {
                Card card1 = players[0].removeTopCard();
                Card card2 = players[1].removeTopCard();

                if (card1.Value == card2.Value)
                {
                    List<Card> warDeck = new List<Card>();
                    warDeck.Add(card1);
                    warDeck.Add(card2);

                    callWar(warDeck);
                }

                else if (card1.Value > card2.Value)
                {
                    players[0].addCard(card1);
                    players[0].addCard(card2);

                    players[0].setScore(players[0].getScore() + 1);
                    players[1].setScore(players[1].getScore() - 1);
                }

                else if (card1.Value < card2.Value)
                {
                    players[1].addCard(card1);
                    players[1].addCard(card2);

                    players[1].setScore(players[1].getScore() + 1);
                    players[0].setScore(players[0].getScore() - 1);
                }

                if (players[0].getScore() == 0 || players[0].getScore() == 52)
                {
                    gameWon = false;
                }

                // Code to determine who won
            }
        }

        public void callWar(List<Card> warDeck)
        { 
            warDeck.Add(players[0].removeTopCard());
            warDeck.Add(players[1].removeTopCard());

            Card card1 = players[0].removeTopCard();
            Card card2 = players[1].removeTopCard();

            warDeck.Add(card1);
            warDeck.Add(card2);

            players[0].setScore(players[0].getScore() - 2);
            players[1].setScore(players[1].getScore() - 2);


            if (card1.Value == card2.Value)
            {
                callWar(warDeck);
            }

            else if (card1.Value > card2.Value)
            {

                foreach (Card c in warDeck)
                {
                    players[0].addCard(c);
                }

                players[0].setScore(players[0].getScore() + warDeck.Count);
            }

            else if (card1.Value < card2.Value)
            {

                foreach (Card c in warDeck)
                {
                    players[1].addCard(c);
                }

                players[1].setScore(players[1].getScore() + warDeck.Count);
            }  
        }     
    }
}
