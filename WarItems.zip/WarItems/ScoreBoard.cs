﻿using System;
using System.Collections.Generic;

namespace COMP4081Project
{
    public class ScoreBoard
    {

        private Dictionary<string, int> playerScores = new Dictionary<string, int>(); // A dictonary to hold all of the scores. This is the equivalent of a HashMap in Java

        public ScoreBoard()
        {
        }

        public void addPlayer(Player player) // Adds a player to the scoreboard
        {
            if (!playerScores.ContainsKey(player.getName())){
                playerScores.Add(player.getName(), player.getScore());
            }
            
        }

        public void updateScores(List<Player> players) // Updates all of the values. This is typically done after each round or each turn, depending on the game. 
        {
           foreach (Player player in players)
            {
                if (playerScores.ContainsKey(player.getName()))
                {
                    playerScores[player.getName()] = player.getScore();
                }

                else
                {
                    addPlayer(player);
                }
            }
        }

        public Dictionary<string, int> getPlayerScores()
        {
            return playerScores;
        }
    }
}